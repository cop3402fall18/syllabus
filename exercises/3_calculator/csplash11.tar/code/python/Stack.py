#!/usr/bin/python

class Stack(list):
  def push(self, x):
    self.append(x)
  def peek(self):
    return self[-1]
  def isEmpty(self):
    return len(self) <= 0

